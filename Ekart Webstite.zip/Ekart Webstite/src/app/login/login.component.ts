import { Component, OnInit } from '@angular/core';
import  db from './../../assets/db.json';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  
  userLoginData={
    email:'',
    password:''
  }
  
  DetailsArray:any=db;
  valid:boolean = false


  response="";
  
  
  constructor() {
    console.log(db)
    console.log(this.valid)
    console.log(this.DetailsArray)
  }

  ngOnInit() {
  }

  userLogin(){
    console.log(this.userLoginData);

    window.sessionStorage.setItem('user',JSON.stringify(this.userLoginData));
    // alert("thaks for your response");

    db.map( (data) =>{
      if( (data.email == this.userLoginData.email) && (data.password == this.userLoginData.password) ){
        this.valid=true
      }
    } )

    if(this.valid){
      event.preventDefault()
      console.log('Valid User')
      console.log(this.valid)
      // window.location.href = '/home'
    }else{
      console.log('Invalid User')
      this.response = "You're Not a valid User"
    }

  }

}
