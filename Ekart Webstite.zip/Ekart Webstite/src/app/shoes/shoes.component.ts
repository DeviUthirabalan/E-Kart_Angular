import { Component, OnInit } from '@angular/core';
import  * as shoes from './../../assets/shoes.json'
import { Router } from '@angular/router';

@Component({
  selector: 'app-shoes',
  templateUrl: './shoes.component.html',
  styleUrls: ['./shoes.component.css']
})
export class ShoesComponent implements OnInit {
  
  ShoesArray:any=(shoes as any).default;


  constructor(private router : Router) {
    console.log(shoes)
   }

  ngOnInit() {
  }

  cartArray:any=[]
  count=0

  addTOCart(name){
    console.log(name);
    this.cartArray[this.count] = name;
    this.count++;
    window.sessionStorage.setItem('shoes',JSON.stringify(this.cartArray))
    console.log(this.cartArray)
  }

  buyNow(shoes){
    console.log(shoes)
    sessionStorage.setItem( 'shoes', JSON.stringify(shoes) )
    this.router.navigate(['/buy-now','shoes'])
    // window.location.href='/products/Shoes/buy-now'
  }

}

