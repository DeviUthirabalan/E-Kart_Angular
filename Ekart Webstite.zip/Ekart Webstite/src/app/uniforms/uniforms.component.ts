import { Component, OnInit } from '@angular/core';
import * as uniforms from './../../assets/uniforms.json'
import { Router } from '@angular/router';

@Component({
  selector: 'app-uniforms',
  templateUrl: './uniforms.component.html',
  styleUrls: ['./uniforms.component.css']
})
export class UniformsComponent implements OnInit {

  UniformsArray:any = (uniforms as any).default

  constructor(private router :Router) {
    console.log(uniforms)
   }
  
  ngOnInit() {
  }

   cartArray:any=[];
   count = 0

   addTOCart(name){
     console.log(uniforms)
     this.cartArray[this.count] = name;
     this.count++;
     window.sessionStorage.setItem('uniforms',JSON.stringify(this.cartArray))

   }

   buyNow(uniforms){
    //console.log(uniforms)
    sessionStorage.setItem( 'uniforms', JSON.stringify(uniforms) )
   this.router.navigate(['/buy-now','uniforms'])
     // window.location.href='/products/Bags/buy-now'
    }

}
