import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import  shoes from './../../assets/shoes.json';
import  uniforms from './../../assets/uniforms.json';
import  bags from './../../assets/bags.json';
import notebooks from './../../assets/notebooks.json';
import { empty } from 'rxjs';
import { ClassGetter } from '@angular/compiler/src/output/output_ast';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {

  constructor(private route : ActivatedRoute) {console.log(this.cartArray) }

  name:string
  cartArray:any =[]
  shoesArray:any=shoes
  uniformsArray:any =uniforms
  BagsArray:any = bags
  NotebooksArray:any =notebooks
  cartProducts:any=[]
  empty ="cart is empty"

  ngOnInit() {

    // this.name = this.route.snapshot.paramMap.get('name')
     //console.log(name)

    // let shoesCart = JSON.parse(window.sessionStorage.getItem('shoes'))
    // this.cartArray.push(shoesCart)

    // let bagsCart = JSON.parse(window.sessionStorage.getItem('bags'))
    // this.cartArray.push(bagsCart)

    // let uniformsCart = JSON.parse(window.sessionStorage.getItem('unifroms'))
    // this.cartArray.push(uniformsCart)

    this.cartArray.push( JSON.parse( window.sessionStorage.getItem('shoes')) || ['None']  )
    this.cartArray.push( JSON.parse( window.sessionStorage.getItem('bags')) || ['None'] )
    this.cartArray.push( JSON.parse( window.sessionStorage.getItem('uniforms')) || ['None'] )
    this.cartArray.push( JSON.parse( window.sessionStorage.getItem('notebooks')))

    console.log(this.cartArray)
    
    // this.cartArray.map( (name) => {

    //   this.shoesArray.map( (shoe) => {
    //     if( name === shoe.name ){
    //       this.cartProducts.push(shoe)
    //     }
    //   } )

    //   this.BagsArray.map( (bags) => {
    //     if( name === bags.name){
    //       this.cartProducts.push(bags)
    //     }    
    //   })


    // } )

    this.cartArray.map( (products) => {

      let prdts = products
      console.log(prdts)

      prdts.map( (product) => {

        this.shoesArray.map( (shoe) => {

          if( product == shoe.name ){
              this.cartProducts.push(shoe)
          }
        })

        this.BagsArray.map( (bags) => {

         if( product == bags.name ){
              this.cartProducts.push(bags)
          }
        })

        this.uniformsArray.map( (uniforms) => {

          if( product == uniforms.name ){
              this.cartProducts.push(uniforms)
          }
        })
        this.NotebooksArray.map( (notebooks) => {

          if( product == notebooks.name ){
              this.cartProducts.push(notebooks)
          }
        })
      })
    } )
    console.log(this.cartProducts)
  }

  clearCart(){
    console.log("ftn called"),
    console.log(this.cartArray),
    sessionStorage.removeItem("shoes"),
    sessionStorage.removeItem("bags"),
    sessionStorage.removeItem("uniforms"),
    sessionStorage.removeItem("notebooks"),
    this.cartArray = [],
    console.log(this.cartArray)
  }

}
