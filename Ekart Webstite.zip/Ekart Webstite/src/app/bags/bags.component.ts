import { Component, OnInit } from '@angular/core';
import  * as bags from './../../assets/bags.json';
import { Router } from '@angular/router'

@Component({
  selector: 'app-bags',
  templateUrl: './bags.component.html',
  styleUrls: ['./bags.component.css']
})
export class BagsComponent implements OnInit {

   BagsArray:any=(bags as any).default
   constructor(private router : Router) {
   // console.log(bags)
   }

  ngOnInit() {
  }
  cartArray:any=[]
  count = 0

  addTOCart(name){
    console.log(name);
    this.cartArray[this.count] = name;
    this.count++;
    window.sessionStorage.setItem('bags',JSON.stringify(this.cartArray))
    console.log(this.cartArray)
  }

  buyNow(bags){
   console.log(bags)
   sessionStorage.setItem( 'bags', JSON.stringify(bags) )
  this.router.navigate(['/buy-now','bags'])
    // window.location.href='/products/Bags/buy-now'
   }

}
