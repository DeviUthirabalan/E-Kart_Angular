import { Component, OnInit } from '@angular/core';
import * as products from './../../assets/products.json'

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {

 
  productArray:any=(products as any).default;

  constructor() {
    console.log(products)
    console.log(this.productArray)
  }

  ngOnInit() {
  }

 

}
