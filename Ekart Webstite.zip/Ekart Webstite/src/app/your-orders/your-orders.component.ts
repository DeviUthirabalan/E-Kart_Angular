import { Component, OnInit } from '@angular/core';
import * as shoes from './../../assets/shoes.json';
import { ActivatedRoute} from '@angular/router'


@Component({
  selector: 'app-your-orders',
  templateUrl: './your-orders.component.html',
  styleUrls: ['./your-orders.component.css']
})
export class YourOrdersComponent implements OnInit {

  name :string;
  product : any = []

  constructor(private router : ActivatedRoute) { }

  // ngOnInit() {
  //   this.name = this.router.snapshot.paramMap.get('name')
  //   this.product = JSON.parse(window.sessionStorage.getItem(this.name))
  // }

  ngOnInit() {
    this.name = this.router.snapshot.paramMap.get('name')
    console.log(this.name)
    this.product = JSON.parse(window.sessionStorage.getItem(this.name))
    console.log(this.product) 
    console.log(this.product.name)
    console.log(this.product.vendor)
    console.log(this.product.price)
    console.log(this.product.availableQuantity)
    //sessionStorage.removeItem(this.name)
  }
}
