import { Component, OnInit } from '@angular/core';
import shoes from './../../assets/shoes.json';
import bags from './../../assets/bags.json';
import notebooks from './../../assets/notebooks.json';
import uniforms from './../../assets/uniforms.json';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-buy-now',
  templateUrl: './buy-now.component.html',
  styleUrls: ['./buy-now.component.css']
})

export class BuyNowComponent implements OnInit {

name:string;
product:any=[]

  constructor(private router : ActivatedRoute) { }

  ngOnInit() {
    this.name = this.router.snapshot.paramMap.get('name')
    console.log(this.name)
    this.product = JSON.parse(window.sessionStorage.getItem(this.name))
    console.log(this.product) 
    console.log(this.product.name)
    console.log(this.product.vendor)
    console.log(this.product.price)
    console.log(this.product.availableQuantity)
    sessionStorage.removeItem(this.name)
  }


  saveAddress(){
    console.log("address saved succesfully")
  }

  reviewOrderDetails(){
    // this.OrdersArray.push(JSON.parse(window.sessionStorage.getItem('Shoes')))
    // console.log(this.OrdersArray);
    
 }

}
