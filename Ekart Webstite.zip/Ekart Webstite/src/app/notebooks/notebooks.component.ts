import { Component, OnInit } from '@angular/core';
import  * as notebooks from './../../assets/notebooks.json';
import {Router} from '@angular/router'

@Component({
  selector: 'app-notebooks',
  templateUrl: './notebooks.component.html',
  styleUrls: ['./notebooks.component.css']
})
export class NotebooksComponent implements OnInit {

  noteBooksArray:any = (notebooks as any).default

  constructor(private Router : Router) {
    console.log(notebooks)
   }

  ngOnInit() {
  }

  cartArray:any=[]
  count = 0

  addTOCart(name){
    console.log(name);
    this.cartArray[this.count] = name;
    this.count++;
    window.sessionStorage.setItem('notebooks',JSON.stringify(this.cartArray))
    console.log(this.cartArray)
  }

  // buyNow(notebooks){
  //   console.log(notebooks)
  //   sessionStorage.setItem('notebooks',JSON.stringify('notebooks'))
  //   //console.log(notebooks)
  //   this.Router.navigate(['/buy-now','notebooks'])
  // }
  buyNow(notebooks){
    console.log(notebooks)
    sessionStorage.setItem( 'notebooks', JSON.stringify(notebooks) )
    this.Router.navigate(['/buy-now','notebooks'])
     //window.location.href='/products/Bags/buy-now'
    }
}
