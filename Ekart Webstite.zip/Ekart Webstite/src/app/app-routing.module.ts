import { NgModule } from '@angular/core';
import { Routes, RouterModule, ActivatedRoute } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { EventsComponent } from './events/events.component';
import { ProductsComponent } from './products/products.component';
import { HomeComponent } from './home/home.component';
import { ShoesComponent } from './shoes/shoes.component';
import { BagsComponent } from './bags/bags.component';
import { ErrorComponent } from './error/error.component';
import { CartComponent } from './cart/cart.component';
import { UniformsComponent } from './uniforms/uniforms.component';
import { NotebooksComponent } from './notebooks/notebooks.component';
import { BuyNowComponent } from './buy-now/buy-now.component';
import { YourOrdersComponent } from './your-orders/your-orders.component';


const routes: Routes = [
  {path:'',redirectTo:'/home', pathMatch:"full"},
  {path:'home', component:HomeComponent},
  {path:'login' ,component:LoginComponent},
  {path:'register' ,component:RegisterComponent},
  {path:'events' ,component:EventsComponent},
  {path:'products' ,component:ProductsComponent},
  {path:'shoes',component:ShoesComponent},
  {path:'products/Shoes' ,component:ShoesComponent},
  {path:'products/Shoes/:name' ,component:BuyNowComponent},
  {path:'Bags',component:BagsComponent},
  {path:'products/Bags',component:BagsComponent},
  {path:'products/Bags/:name',component:BuyNowComponent},
  {path:'uniforms',component:UniformsComponent},
  {path:'products/Uniform',component:UniformsComponent},
  {path:'products/Uniform/:name',component:BuyNowComponent},
  {path:'notebooks',component:NotebooksComponent},
  {path:'products/notebooks',component:NotebooksComponent},
  {path:'products/notebooks/:name',component:BuyNowComponent},
  {path:'buy-now/:name',component:BuyNowComponent},
  //{path:'products/Uniform/buy-now/:name',component:BuyNowComponent},
  
  {path:'cart' ,component:CartComponent},
  {path:'Orders',component:YourOrdersComponent},
  {path:'buy-now/:name/Orders',component:YourOrdersComponent},
  {path:'cart/:name' ,component:BuyNowComponent},
 {path:'**', component:ErrorComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { 
// constructor(private route: ActivatedRoute) {}
}