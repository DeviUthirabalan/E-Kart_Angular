import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from'@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { ProductsComponent } from './products/products.component';
import { EventsComponent } from './events/events.component';
import { HomeComponent } from './home/home.component';
import { ShoesComponent } from './shoes/shoes.component';
import { BagsComponent } from './bags/bags.component';
import { ErrorComponent } from './error/error.component';
import { CartComponent } from './cart/cart.component';
import { UniformsComponent } from './uniforms/uniforms.component';
import { NotebooksComponent } from './notebooks/notebooks.component';
import { BuyNowComponent } from './buy-now/buy-now.component';
import { NavbarComponent } from './navbar/navbar.component';
import { YourOrdersComponent } from './your-orders/your-orders.component';


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegisterComponent,
    ProductsComponent,
    EventsComponent,
    HomeComponent,
    ShoesComponent,
    BagsComponent,
    ErrorComponent,
    CartComponent,
    UniformsComponent,
    NotebooksComponent,
    BuyNowComponent,
    NavbarComponent,
    YourOrdersComponent,
   
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
